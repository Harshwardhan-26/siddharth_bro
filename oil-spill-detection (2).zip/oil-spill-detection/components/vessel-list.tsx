"use client"

import { useState, useEffect } from "react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { AlertTriangle, MoreHorizontal, Eye } from "lucide-react"
import { fetchVessels } from "@/lib/api"
import type { Vessel } from "@/lib/types"

export default function VesselList() {
  const [vessels, setVessels] = useState<Vessel[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const loadVessels = async () => {
      setIsLoading(true)
      const data = await fetchVessels()
      setVessels(data)
      setIsLoading(false)
    }

    loadVessels()
  }, [])

  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Vessel Name</TableHead>
            <TableHead>MMSI</TableHead>
            <TableHead>Type</TableHead>
            <TableHead>Position</TableHead>
            <TableHead>Speed (knots)</TableHead>
            <TableHead>Course</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="w-[80px]">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {isLoading ? (
            <TableRow>
              <TableCell colSpan={8} className="text-center py-10">
                Loading vessel data...
              </TableCell>
            </TableRow>
          ) : vessels.length === 0 ? (
            <TableRow>
              <TableCell colSpan={8} className="text-center py-10">
                No vessels found
              </TableCell>
            </TableRow>
          ) : (
            vessels.map((vessel) => (
              <TableRow key={vessel.id} className={vessel.isAnomaly ? "bg-amber-50" : ""}>
                <TableCell className="font-medium">
                  {vessel.name}
                  {vessel.isAnomaly && <AlertTriangle className="h-4 w-4 inline ml-2 text-amber-500" />}
                </TableCell>
                <TableCell>{vessel.mmsi}</TableCell>
                <TableCell>{vessel.type}</TableCell>
                <TableCell>
                  {vessel.latitude.toFixed(4)}, {vessel.longitude.toFixed(4)}
                </TableCell>
                <TableCell>{vessel.speed}</TableCell>
                <TableCell>{vessel.course}°</TableCell>
                <TableCell>
                  {vessel.isAnomaly ? (
                    <Badge variant="outline" className="bg-amber-100 text-amber-800 border-amber-300">
                      Anomaly
                    </Badge>
                  ) : (
                    <Badge variant="outline" className="bg-green-100 text-green-800 border-green-300">
                      Normal
                    </Badge>
                  )}
                </TableCell>
                <TableCell>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem>
                        <Eye className="h-4 w-4 mr-2" />
                        View Details
                      </DropdownMenuItem>
                      <DropdownMenuItem>Track History</DropdownMenuItem>
                      <DropdownMenuItem>Generate Report</DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </div>
  )
}

