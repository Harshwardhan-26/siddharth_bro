"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { AlertTriangle, CheckCircle, Clock, Droplets, MapPin, Ship, Eye } from "lucide-react"
import { fetchAlerts } from "@/lib/api"
import type { Alert } from "@/lib/types"

export default function AlertsPanel() {
  const [alerts, setAlerts] = useState<Alert[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const loadAlerts = async () => {
      setIsLoading(true)
      const data = await fetchAlerts()
      setAlerts(data)
      setIsLoading(false)
    }

    loadAlerts()
  }, [])

  const getAlertsByType = (type: string) => {
    return alerts.filter((alert) => alert.type === type)
  }

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "high":
        return "bg-red-100 text-red-800 border-red-300"
      case "medium":
        return "bg-amber-100 text-amber-800 border-amber-300"
      case "low":
        return "bg-blue-100 text-blue-800 border-blue-300"
      default:
        return "bg-gray-100 text-gray-800 border-gray-300"
    }
  }

  const getAlertIcon = (type: string) => {
    switch (type) {
      case "oil_spill":
        return <Droplets className="h-5 w-5 text-red-500" />
      case "vessel_anomaly":
        return <Ship className="h-5 w-5 text-amber-500" />
      default:
        return <AlertTriangle className="h-5 w-5 text-gray-500" />
    }
  }

  const renderAlertCard = (alert: Alert) => (
    <Card key={alert.id} className="mb-4">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <div className="flex items-center gap-2">
            {getAlertIcon(alert.type)}
            <CardTitle className="text-base">{alert.title}</CardTitle>
          </div>
          <Badge variant="outline" className={getSeverityColor(alert.severity)}>
            {alert.severity.charAt(0).toUpperCase() + alert.severity.slice(1)} Severity
          </Badge>
        </div>
        <CardDescription className="text-xs flex items-center mt-1">
          <Clock className="h-3 w-3 mr-1" />
          {new Date(alert.timestamp).toLocaleString()}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <p className="text-sm">{alert.description}</p>
        <div className="flex items-center mt-2 text-xs text-muted-foreground">
          <MapPin className="h-3 w-3 mr-1" />
          {alert.location}
        </div>
      </CardContent>
      <CardFooter className="flex justify-between pt-2">
        <Button variant="outline" size="sm">
          <Eye className="h-4 w-4 mr-2" />
          View on Map
        </Button>
        <Button variant="default" size="sm">
          <CheckCircle className="h-4 w-4 mr-2" />
          Mark as Resolved
        </Button>
      </CardFooter>
    </Card>
  )

  return (
    <div>
      <Tabs defaultValue="all">
        <TabsList>
          <TabsTrigger value="all">All Alerts</TabsTrigger>
          <TabsTrigger value="oil_spill">Oil Spills</TabsTrigger>
          <TabsTrigger value="vessel_anomaly">Vessel Anomalies</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="mt-4">
          {isLoading ? (
            <p className="text-center py-10">Loading alerts...</p>
          ) : alerts.length === 0 ? (
            <p className="text-center py-10">No alerts found</p>
          ) : (
            alerts.map((alert) => renderAlertCard(alert))
          )}
        </TabsContent>

        <TabsContent value="oil_spill" className="mt-4">
          {isLoading ? (
            <p className="text-center py-10">Loading alerts...</p>
          ) : getAlertsByType("oil_spill").length === 0 ? (
            <p className="text-center py-10">No oil spill alerts found</p>
          ) : (
            getAlertsByType("oil_spill").map((alert) => renderAlertCard(alert))
          )}
        </TabsContent>

        <TabsContent value="vessel_anomaly" className="mt-4">
          {isLoading ? (
            <p className="text-center py-10">Loading alerts...</p>
          ) : getAlertsByType("vessel_anomaly").length === 0 ? (
            <p className="text-center py-10">No vessel anomaly alerts found</p>
          ) : (
            getAlertsByType("vessel_anomaly").map((alert) => renderAlertCard(alert))
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}

