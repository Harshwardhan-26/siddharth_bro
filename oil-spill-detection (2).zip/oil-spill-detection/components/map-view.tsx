"use client"

import { useEffect, useState } from "react"
import { MapContainer, TileLayer, Marker, Popup, Circle } from "react-leaflet"
import "leaflet/dist/leaflet.css"
import L from "leaflet"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Layers, AlertTriangle, Droplets, SailboatIcon as Boat } from "lucide-react"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { fetchVessels, fetchOilSpills } from "@/lib/api"
import type { Vessel, OilSpill } from "@/lib/types"

// Fix for Leaflet marker icons in Next.js
const createIcon = (iconUrl: string, className: string) => {
  return L.divIcon({
    className: className,
    iconSize: [20, 20],
    iconAnchor: [10, 10],
    popupAnchor: [0, -10],
  })
}

export default function MapView() {
  const [vessels, setVessels] = useState<Vessel[]>([])
  const [oilSpills, setOilSpills] = useState<OilSpill[]>([])
  const [showVessels, setShowVessels] = useState(true)
  const [showAnomalies, setShowAnomalies] = useState(true)
  const [showOilSpills, setShowOilSpills] = useState(true)

  useEffect(() => {
    const loadData = async () => {
      const vesselData = await fetchVessels()
      const spillData = await fetchOilSpills()

      setVessels(vesselData)
      setOilSpills(spillData)
    }

    loadData()
  }, [])

  const vesselIcon = createIcon("/placeholder.svg?height=20&width=20", "vessel-marker")
  const anomalyIcon = createIcon("/placeholder.svg?height=20&width=20", "vessel-anomaly-marker")
  const spillIcon = createIcon("/placeholder.svg?height=20&width=20", "oil-spill-marker")

  return (
    <div className="relative h-full">
      <MapContainer center={[25.0, -90.0]} zoom={5} className="h-full w-full">
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />

        {/* Vessels */}
        {showVessels &&
          vessels.map((vessel) => (
            <Marker
              key={vessel.id}
              position={[vessel.latitude, vessel.longitude]}
              icon={vessel.isAnomaly && showAnomalies ? anomalyIcon : vesselIcon}
            >
              <Popup>
                <div className="p-1">
                  <h3 className="font-bold">{vessel.name}</h3>
                  <p className="text-sm">MMSI: {vessel.mmsi}</p>
                  <p className="text-sm">Speed: {vessel.speed} knots</p>
                  <p className="text-sm">Course: {vessel.course}°</p>
                  {vessel.isAnomaly && (
                    <Badge variant="outline" className="mt-1 bg-amber-100 text-amber-800 border-amber-300">
                      Anomaly Detected
                    </Badge>
                  )}
                </div>
              </Popup>
            </Marker>
          ))}

        {/* Oil Spills */}
        {showOilSpills &&
          oilSpills.map((spill) => (
            <div key={spill.id}>
              <Marker position={[spill.latitude, spill.longitude]} icon={spillIcon}>
                <Popup>
                  <div className="p-1">
                    <h3 className="font-bold">Oil Spill #{spill.id}</h3>
                    <p className="text-sm">Detected: {new Date(spill.detectedAt).toLocaleString()}</p>
                    <p className="text-sm">Severity: {spill.severity}</p>
                    <p className="text-sm">Confidence: {spill.confidence}%</p>
                    <Button size="sm" variant="destructive" className="mt-2 w-full">
                      <AlertTriangle className="h-4 w-4 mr-1" />
                      Send Alert
                    </Button>
                  </div>
                </Popup>
              </Marker>
              <Circle
                center={[spill.latitude, spill.longitude]}
                radius={spill.radius * 1000}
                pathOptions={{
                  color: "red",
                  fillColor: "red",
                  fillOpacity: 0.2,
                }}
              />
            </div>
          ))}
      </MapContainer>

      {/* Map Controls */}
      <Card className="absolute top-4 right-4 z-[1000] w-64">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm flex items-center">
            <Layers className="h-4 w-4 mr-2" />
            Map Layers
          </CardTitle>
          <CardDescription className="text-xs">Toggle map elements</CardDescription>
        </CardHeader>
        <CardContent className="space-y-2">
          <div className="flex items-center space-x-2">
            <Checkbox
              id="show-vessels"
              checked={showVessels}
              onCheckedChange={(checked) => setShowVessels(checked as boolean)}
            />
            <Label htmlFor="show-vessels" className="flex items-center text-sm">
              <Boat className="h-4 w-4 mr-2 text-blue-500" />
              Vessels
            </Label>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox
              id="show-anomalies"
              checked={showAnomalies}
              onCheckedChange={(checked) => setShowAnomalies(checked as boolean)}
            />
            <Label htmlFor="show-anomalies" className="flex items-center text-sm">
              <AlertTriangle className="h-4 w-4 mr-2 text-amber-500" />
              Anomalies
            </Label>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox
              id="show-spills"
              checked={showOilSpills}
              onCheckedChange={(checked) => setShowOilSpills(checked as boolean)}
            />
            <Label htmlFor="show-spills" className="flex items-center text-sm">
              <Droplets className="h-4 w-4 mr-2 text-red-500" />
              Oil Spills
            </Label>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

