import Dashboard from "@/components/dashboard"
import AppSidebar from "@/components/app-sidebar"

export default function Home() {
  return (
    <main className="flex min-h-screen">
      <AppSidebar />
      <div className="flex-1">
        <Dashboard />
      </div>
    </main>
  )
}

