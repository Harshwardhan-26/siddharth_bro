export interface Vessel {
  id: string
  name: string
  mmsi: string
  type: string
  latitude: number
  longitude: number
  speed: number
  course: number
  isAnomaly: boolean
  anomalyReason?: string
}

export interface OilSpill {
  id: string
  latitude: number
  longitude: number
  radius: number
  severity: string
  confidence: number
  detectedAt: string
  source: string
}

export interface Alert {
  id: string
  type: string
  title: string
  description: string
  severity: string
  timestamp: string
  location: string
  isResolved: boolean
}

