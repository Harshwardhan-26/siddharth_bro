import type { Vessel, OilSpill, Alert } from "./types"

// Mock data for vessels
const mockVessels: Vessel[] = [
  {
    id: "v1",
    name: "Oceanic Explorer",
    mmsi: "123456789",
    type: "Cargo",
    latitude: 29.7604,
    longitude: -95.3698,
    speed: 12.5,
    course: 135,
    isAnomaly: false,
  },
  {
    id: "v2",
    name: "Gulf Trader",
    mmsi: "987654321",
    type: "Tanker",
    latitude: 29.6,
    longitude: -95.2,
    speed: 0.5,
    course: 90,
    isAnomaly: true,
    anomalyReason: "Sudden speed drop",
  },
  {
    id: "v3",
    name: "Coastal Voyager",
    mmsi: "456789123",
    type: "Passenger",
    latitude: 29.5,
    longitude: -94.8,
    speed: 15.2,
    course: 180,
    isAnomaly: false,
  },
  {
    id: "v4",
    name: "Horizon Tanker",
    mmsi: "789123456",
    type: "Tanker",
    latitude: 28.8,
    longitude: -94.5,
    speed: 8.7,
    course: 225,
    isAnomaly: true,
    anomalyReason: "Erratic movement pattern",
  },
  {
    id: "v5",
    name: "Atlantic Freighter",
    mmsi: "321654987",
    type: "Cargo",
    latitude: 28.3,
    longitude: -94.2,
    speed: 14.3,
    course: 270,
    isAnomaly: false,
  },
]

// Mock data for oil spills
const mockOilSpills: OilSpill[] = [
  {
    id: "s1",
    latitude: 29.2,
    longitude: -94.9,
    radius: 2.5,
    severity: "high",
    confidence: 85,
    detectedAt: "2023-06-15T08:30:00Z",
    source: "Sentinel-1 SAR",
  },
  {
    id: "s2",
    latitude: 28.7,
    longitude: -95.1,
    radius: 1.2,
    severity: "medium",
    confidence: 72,
    detectedAt: "2023-06-14T14:45:00Z",
    source: "MODIS",
  },
  {
    id: "s3",
    latitude: 28.9,
    longitude: -94.6,
    radius: 0.8,
    severity: "low",
    confidence: 65,
    detectedAt: "2023-06-13T22:15:00Z",
    source: "Sentinel-2 MSI",
  },
]

// Mock data for alerts
const mockAlerts: Alert[] = [
  {
    id: "a1",
    type: "oil_spill",
    title: "Major Oil Spill Detected",
    description:
      "Satellite imagery has detected a large oil spill approximately 15km offshore. High confidence detection requires immediate response.",
    severity: "high",
    timestamp: "2023-06-15T08:35:00Z",
    location: "Gulf of Mexico, 29.2°N, 94.9°W",
    isResolved: false,
  },
  {
    id: "a2",
    type: "vessel_anomaly",
    title: "Suspicious Vessel Behavior",
    description:
      "Tanker 'Gulf Trader' has shown unusual movement patterns and a sudden drop in speed near a sensitive area.",
    severity: "medium",
    timestamp: "2023-06-15T07:15:00Z",
    location: "Houston Ship Channel, 29.6°N, 95.2°W",
    isResolved: false,
  },
  {
    id: "a3",
    type: "oil_spill",
    title: "Potential Oil Slick",
    description: "Medium confidence detection of a possible oil slick. Requires verification with additional imagery.",
    severity: "medium",
    timestamp: "2023-06-14T14:50:00Z",
    location: "Gulf of Mexico, 28.7°N, 95.1°W",
    isResolved: false,
  },
  {
    id: "a4",
    type: "vessel_anomaly",
    title: "Erratic Movement Pattern",
    description:
      "Vessel 'Horizon Tanker' is displaying erratic movement patterns that may indicate mechanical issues or unauthorized activities.",
    severity: "medium",
    timestamp: "2023-06-14T10:20:00Z",
    location: "Gulf of Mexico, 28.8°N, 94.5°W",
    isResolved: true,
  },
  {
    id: "a5",
    type: "oil_spill",
    title: "Minor Oil Sheen",
    description: "Small oil sheen detected with low confidence. May be natural seepage or minor release.",
    severity: "low",
    timestamp: "2023-06-13T22:20:00Z",
    location: "Gulf of Mexico, 28.9°N, 94.6°W",
    isResolved: true,
  },
]

// API functions to fetch data
export async function fetchVessels(): Promise<Vessel[]> {
  // In a real application, this would be an API call
  return new Promise((resolve) => {
    setTimeout(() => resolve(mockVessels), 500)
  })
}

export async function fetchOilSpills(): Promise<OilSpill[]> {
  // In a real application, this would be an API call
  return new Promise((resolve) => {
    setTimeout(() => resolve(mockOilSpills), 500)
  })
}

export async function fetchAlerts(): Promise<Alert[]> {
  // In a real application, this would be an API call
  return new Promise((resolve) => {
    setTimeout(() => resolve(mockAlerts), 500)
  })
}

// API function to detect anomalies in vessel behavior
export async function detectVesselAnomalies(vesselData: any[]): Promise<any[]> {
  // This would be a server-side function that uses ML models
  // For demonstration, we're just returning mock data
  return mockVessels.filter((v) => v.isAnomaly)
}

// API function to detect oil spills from satellite imagery
export async function detectOilSpills(satelliteData: any): Promise<any[]> {
  // This would be a server-side function that uses ML models
  // For demonstration, we're just returning mock data
  return mockOilSpills
}

// API function to send alerts
export async function sendAlert(alertData: Partial<Alert>): Promise<Alert> {
  // This would send an alert via SMS, email, etc.
  // For demonstration, we're just returning the data
  const newAlert: Alert = {
    id: `a${mockAlerts.length + 1}`,
    type: alertData.type || "other",
    title: alertData.title || "New Alert",
    description: alertData.description || "",
    severity: alertData.severity || "medium",
    timestamp: new Date().toISOString(),
    location: alertData.location || "Unknown",
    isResolved: false,
  }

  return new Promise((resolve) => {
    setTimeout(() => resolve(newAlert), 500)
  })
}

